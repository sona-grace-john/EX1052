//Js code should be executed in "strict mode"
"use strict";
//require the express and body-parser modules
const express = require('express');
const bodyParser = require('body-parser');
//create an Express application and en Express router.

//require the sqlite3 package
const sqlite3 = require('sqlite3').verbose();

//create a database object
const database = new sqlite3.Database("./my.db");

//require jsonwebtoken and bcryptjs:
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
//a secret key to sign the payloads to create JSON tokens:
const SECRET_KEY = "secretkey23456";


const app = express();
const router = express.Router();
router.use(bodyParser.urlencoded({ extended: false }));
router.use(bodyParser.json());

router.post('/register', (req, res) => {
    res.status(200).send({ accessToken: '' });
    });
    router.post('/login', (req, res) => {
    res.status(200).send({ accessToken: '' });
    });
    //This function is passed two object

    app.use(router);
    const port = process.env.PORT || 3005;
    const server = app.listen(port, () => {
    console.log('Server listening at http://localhost:' +
    port);
    });
    //we can run our server using t

    router.get('/', (req, res) => {
        res.status(200).send('This is an authenticationserver');
        });


        const createUsersTable = () => {

            const sqlQuery =
            `
            
            CREATE TABLE IF NOT EXISTS users (
            id integer PRIMARY KEY,
            name text,
            email text UNIQUE,
            password text)`;
            
            return database.run(sqlQuery);
            
            }      
            
            const findUserByEmail = (email, cb) => {
                return database.get(`SELECT * FROM users WHERE email = ?`, [email], (err, row) => {
                cb(err, row)
                });
                }
                
                const createUser = (user, cb) => {
                return database.run('INSERT INTO users (name, email, password) VALUES (?,?,?)', user, (err) => {cb(err)
                });
                }
                
                // let’s create the users table by calling the createUsersTable()
                createUsersTable();
      
