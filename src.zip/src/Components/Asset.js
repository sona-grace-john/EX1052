import React from 'react'
import {Link} from 'react-router-dom'
import {useNavigate} from 'react-router-dom'
import axios from 'axios'

import {Table,Nav,Button} from 'react-bootstrap'

function Asset(props) {

    const navigate = useNavigate()
    console.log(props)
    var linkstyle = {
        padding : 5,
        backgroundColor :'navyblue',
        color : 'white'
    }
    return(
        <div>
        <div style={{
                    marginTop: 30, 
                    width: 600, 
                    marginLeft : '33%',
                  }}>
        <Table striped  hover variant='lg' className='color-table'>
            <tbody>
                <tr>
                    
{/*<td> <img src={props.details.Url} alt='Asset Cover' width='100px' height='100px' onClick={() => history.push(`/assets/${props.details.AssetID}`)} /></td>
                    <td>
                    <h4 marginTop='20px'>{props.details.AssetName}</h4>
                    </td>
                    <td>
                    <Link to={`/assets/${props.details.AssetID}`}><h4 marginTop='20px'>{props.details.AssetName}</h4></Link>
                    </td>*/}
                    <td>
                        <Nav.Link variant='pills' href={`/assets/${props.details.AssetID}`}><img src={props.details.URL} alt='Asset Cover' width='100px' height='100px' /></Nav.Link>
                    </td>
                    <td >
                        <Nav.Link variant='pills' href={`/assets/${props.details.AssetID}`}><h4 style={{marginTop:'30px',color:'black'}}>{props.details.ModelName}</h4></Nav.Link>
                    </td>
                    <td>
                    <Button type='button' variant='primary' onClick={() => navigate(`/editassets/${props.details.AssetID}`)} style={{marginTop:'40px',backgroundColor:'white',border:'none',color:'rgb(85, 205, 255)'}} >Edit</Button>
                    </td>
                    <td>
                    <Button type='button' variant='primary' onClick={()=>DeleteAsset(props.details.AssetID)} style={{marginTop:'40px',backgroundColor:'white',border:'none',color:'rgb(85, 205, 255)'}}>Delete</Button>
                    </td>
                </tr>
            </tbody>
            </Table>
            </div>
        </div>
    )

    function DeleteAsset(id){
        console.log('Delete1 promise was fulfilled')
        axios   
            .delete(`http://localhost:4000/assets/${id}`)
            .then(response => {
                console.log('Delete promise was fulfilled')
                console.log(response)
            })
            window.location= '/assets'
    }
}

export default Asset