import React from 'react'

function NoMatch() {
    return (
        <div>
            <h1>Oops!!</h1>
            <h3>You seems to have reached a non existing record</h3>
        </div>
    )
}

export default NoMatch
