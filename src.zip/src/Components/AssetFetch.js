import {useState, useEffect} from 'react'
import axios from 'axios'
import Asset from './Asset.js'

function AssetFetch(){
    const [assets,setAssets] = useState([])

    useEffect(() => {
        console.log('The use effect hook has been executed')

        axios   
            .get('http://localhost:4000/assets/')
            .then(response => {
                console.log('promise fulfilled')
                console.log(response)
                setAssets(response.data)
            })
    },[])

    return(
        <>
            <div style={{marginTop:'50px'}}>
                <h1 style={{color:'rgb(218, 153, 79)'}}>Asset List</h1>
                <ul>
                    {
                        assets.map(asset => 
                            <span key={asset.AssetID}><Asset details={asset}/></span>
                        )
                    }
                </ul>
            </div>
        </>
    )
}

export default AssetFetch