import { useState,useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router";

import {Form,Button} from 'react-bootstrap'

function Register(){
    const {id} = useParams()
    return(
        <>
            <h1 style={{marginTop:30,color:'rgb(218, 153, 79)'}}>Register</h1>
            <MyForm id={id} />
        </>
    )
}


function MyForm(props){
    const [register,setRegister] = useState({})
    const [submitted,setSubmitted] = useState(false)

    useEffect(() => {
        axios
            .get(`http://localhost:4000/register/`)
            .then(response => {
                console.log(response)
                setRegister(response.data)
            })
    },[])

    function handleChange(event){
        const name = event.target.name
        const value = event.target.value
        setRegister(values => ({...values, [name]:value}))
    }

    function handleSubmit(event){
        event.preventDefault()
        console.log(register)
        axios
            .post(`http://localhost:4000/register/`,register)
            .then(response => {
                console.log(response)
                alert('Registered Successfully')
            })
    }

    const handleReset = () => {
        console.clear()
        setSubmitted(false)
    }

    return (
        <div>
            <div style={{ 
                    display: 'block', 
                    width: 700, 
                    padding: 30 ,
                    marginLeft : '35%',
                    marginTop : 30,
                    backgroundColor : 'rgb(85, 205, 255)'
                  }} > 
                <Form onSubmit={handleSubmit}>
                    {submitted?<div>Success!Asset Added</div>:null}
                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id= 'Name'
                        type= 'text'
                        placeholder='Enter Name'
                        name = 'Name'
                        value = {register.Name}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>

                    <Form.Group className='mb-3' controlId='formAuthor'>
                        <Form.Control
                        className='Form-Control'
                        id='Email'
                        type='text'
                        placeholder='Enter Serial Number'
                        name = 'Email'
                        value = {register.Email}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>

                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id='Phone'
                        type='number'
                        placeholder='Enter Phone'
                        name = 'Phone'
                        value = {register.Phone}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>



                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id='Password'
                        type='text'
                        placeholder='Enter Password'
                        name = 'Password'
                        value = {register.Password}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>


                <Button type='submit' variant='primary' style={{backgroundColor:'white',border:'none',color:'rgb(85, 205, 255)'}}>Register</Button>
                <Button type='reset' variant='primary' style={{backgroundColor:'white',border:'none',color:'rgb(85, 205, 255)',marginLeft:20}} onClick={handleReset} >Cancel</Button>
                </Form>
            </div>        
        </div>
    )
}


export default Register