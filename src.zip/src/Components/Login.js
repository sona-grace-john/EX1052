import { useState, useEffect } from "react";
import axios from "axios";
import {useNavigate} from 'react-router-dom'
function Login(){
return (<>
<h1>Please Login</h1>
<MyForm/>
</>);
}

function MyForm(props) {
    const navigate = useNavigate();
    //initialize useState with emtpy {} and it will return 2 values,
    //The current state, and a function that updates the state.
    const [inputs, setInputs] = useState({});
    function handleChange(event){
    //during change of every element.
    //save name in 'name' and its value in value
    const name = event.target.name;
    const value = event.target.value;
    // setInputs is the function that updates the state.
    setInputs(values => ({...values, [name]: value}))
    }


function handleSubmit(event) {
    localStorage.clear();
    //localStorage.removeItem('mytoken');
    //localStorage.clear();
    //to prevent default html form submit behaviour
    event.preventDefault();
    //alert the current state
    console.log(inputs);
    axios
    .get(`http://localhost:3002/login/`,inputs)
    .then(response => {
    console.log('login promise was fullfilled')
    console.log(response)
    })


axios
.get(`http://localhost:3002/login/`,inputs)
.then(response => {
console.log('login promise was fullfilled')
console.log(response)
// local storage setter
localStorage.setItem('mytoken'
, response.data[0].access_token);
// local storage getter
console.log(localStorage.getItem('mytoken'));
// local storage remove
//localStorage.removeItem('mytoken');
// local storage remove all
//localStorage.clear();


if (localStorage.getItem('mytoken')==='undefined') {
    localStorage.clear();
    alert("Cannot Login. Please try again")
    } 
    else {
    navigate(`/stafflist`)
    }
})
}


return (
    <form onSubmit={handleSubmit}>
    <label>User Id:
    <input type="text" name=
    "user_id"
    value={inputs.user_id || ""}
    onChange={handleChange}
    required />
    <br/><br/>
    </label>

    <label>Password:
<input type="password" name="password"
value={inputs.password || ""}
onChange={handleChange}
required />
<br/><br/>
</label>
<input type="submit" />
</form>
)
}
export default Login;