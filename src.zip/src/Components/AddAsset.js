import axios from 'axios'
import React,{useState} from 'react'

import {Form,Button} from 'react-bootstrap'


function AddAsset() {
    const [assets,setAssets] = useState({})
    const [submitted,setSubmitted] = useState(false)
    
    function handleChange(event){
        const name = event.target.name
        const value = event.target.value

        setAssets(values => ({...values,[name]:value}))
    }

    const handleSubmit = (event) => {
        console.log(assets)
        event.preventDefault()
        setSubmitted(true)

            axios   
                .post('http://localhost:4000/assets/',assets)
                .then(response => {
                    console.log(response)
                    alert(`${assets.ModelName} added successfully`)
                })
                .catch(error => {
                    console.log(error)
                })
    }

    const handleReset = () => {
        console.clear()
        setSubmitted(false)
    }
    
    return (
        <div>
            <div style={{ 
                    display: 'block', 
                    width: 700, 
                    padding: 30 ,
                    marginLeft : '35%',
                    marginTop : 50,
                    backgroundColor : 'rgb(85, 205, 255)'
                  }} > 
                <Form onSubmit={handleSubmit}>
                    {submitted?<div>Success!Asset Added</div>:null}
                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id= 'ModelName'
                        type= 'text'
                        placeholder='Enter Modelname'
                        name = 'ModelName'
                        value = {assets.ModelName}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>

                    <Form.Group className='mb-3' controlId='formAuthor'>
                        <Form.Control
                        className='Form-Control'
                        id='SerialNumber'
                        type='text'
                        placeholder='Enter Serial Number'
                        name = 'SerialNumber'
                        value = {assets.SerialNumber}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>

                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id='MyYear'
                        type='number'
                        placeholder='Enter MyYear'
                        name = 'MyYear'
                        value = {assets.Myyear}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>

                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id='PurchaseDate'
                        type='date'
                        placeholder='Enter PurchaseDate'
                        name = 'PurchaseDate'
                        value = {assets.PurchaseDate}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>


                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id='Warranty'
                        type='text'
                        placeholder='Enter Warranty'
                        name = 'Warranty'
                        value = {assets.Warranty}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>


                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id='From'
                        type='date'
                        placeholder='Enter From Date'
                        name = 'From'
                        value = {assets.From}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>
                    

                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id='To'
                        type='date'
                        placeholder='Enter To date'
                        name = 'To'
                        value = {assets.To}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>

                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id='URL'
                        type='text'
                        placeholder='Enter Image URL'
                        name = 'URL'
                        value = {assets.URL}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>

                <Button type='submit' variant='primary' style={{backgroundColor:'white',border:'none',color:'rgb(85, 205, 255)'}}>Register</Button>
                <Button type='reset' variant='primary' style={{backgroundColor:'white',border:'none',color:'rgb(85, 205, 255)',marginLeft:20}} onClick={handleReset} >Cancel</Button>
                </Form>
            </div>        
        </div>
    )
}


export default AddAsset