import { useState,useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router";

import {Form,Button} from 'react-bootstrap'

function AssetEdit(){
    const {id} = useParams()
    return(
        <>
            <h1 style={{marginTop:30,color:'rgb(85, 205, 255)'}}>Asset Edit</h1>
            <MyForm id={id} />
        </>
    )
}


function MyForm(props){
    const [assets,setAssets] = useState({})
    const [submitted,setSubmitted] = useState(false)

    useEffect(() => {
        axios
            .get(`http://localhost:4000/assets/${props.id}`)
            .then(response => {
                console.log(response)
                setAssets(response.data)
            })
    },[])

    function handleChange(event){
        const name = event.target.name
        const value = event.target.value
        setAssets(values => ({...values, [name]:value}))
    }

    function handleSubmit(event){
        event.preventDefault()
        console.log(assets)
        axios
            .put(`http://localhost:4000/assets/${props.id}`,assets)
            .then(response => {
                console.log(response)
                alert('User details updated')
            })
    }

    const handleReset = () => {
        console.clear()
        setSubmitted(false)
    }

    return (
        <div>
            <div style={{ 
                    display: 'block', 
                    width: 700, 
                    padding: 30 ,
                    marginLeft : '35%',
                    marginTop : 30,
                    backgroundColor : 'rgb(85, 205, 255)'
                  }} > 
                <Form onSubmit={handleSubmit}>
                    {submitted?<div>Success!Asset Added</div>:null}
                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id= 'ModelName'
                        type= 'text'
                        placeholder='Enter Modelname'
                        name = 'ModelName'
                        value = {assets.ModelName}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>

                    <Form.Group className='mb-3' controlId='formAuthor'>
                        <Form.Control
                        className='Form-Control'
                        id='SerialNumber'
                        type='text'
                        placeholder='Enter Serial Number'
                        name = 'SerialNumber'
                        value = {assets.SerialNumber}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>

                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id='MyYear'
                        type='number'
                        placeholder='Enter MyYear'
                        name = 'MyYear'
                        value = {assets.Myyear}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>

                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id='PurchaseDate'
                        type='date'
                        placeholder='Enter PurchaseDate'
                        name = 'PurchaseDate'
                        value = {assets.PurchaseDate}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>


                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id='Warranty'
                        type='text'
                        placeholder='Enter Warranty'
                        name = 'Warranty'
                        value = {assets.Warranty}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>


                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id='From'
                        type='date'
                        placeholder='Enter From Date'
                        name = 'From'
                        value = {assets.From}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>
                    

                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id='To'
                        type='date'
                        placeholder='Enter To date'
                        name = 'To'
                        value = {assets.To}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>

                    <Form.Group className='mb-3' controlId='formAssetName'>
                        <Form.Control
                        className='Form-Control'
                        id='URL'
                        type='text'
                        placeholder='Enter Image URL'
                        name = 'URL'
                        value = {assets.URL}
                        onChange = {handleChange}
                        required
                    />
                    </Form.Group>

                <Button type='submit' variant='primary' style={{backgroundColor:'white',border:'none',color:'rgb(85, 205, 255)'}}>Update</Button>
                <Button type='reset' variant='primary' style={{backgroundColor:'white',border:'none',color:'rgb(85, 205, 255)',marginLeft:20}} onClick={handleReset} >Cancel</Button>
                </Form>
            </div>        
        </div>
    )
}


export default AssetEdit