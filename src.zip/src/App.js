import './App.css';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import Home from './Components/Home';
import About from './Components/About';
//import AssetList from './Components/AssetFetch';
import NoMatch from './Components/NoMatch';
import AssetFetch from './Components/AssetFetch';
import AssetDetails from './Components/AssetDetails';
import AddAsset from './Components/AddAsset';
import AssetEdit from './Components/AssetEdit';

import 'bootstrap/dist/css/bootstrap.min.css';
import { Navbar, Container, Nav } from 'react-bootstrap'
import {MDBContainer,MDBFooter} from 'mdbreact'
import Register from './Components/RegisterAdmin';
import Login from './Components/Login';

function App() {
  return (
    <div className="App">
      <MyRouter />
    </div>
  );
}


function MyRouter() {
  var layLow = {
    position : 'fixed',
    bottom : 0,
    textAlign : 'center',
    width : '100%',
    padding : 20,
    color: 'white'
  }
  return (
    <>
    <Router>
      
      <h1>
      <div style={{
            marginTop: 40, 
            padding : 10,
            backgroundColor : 'rgb(85, 205, 255)',
            color : 'GREY'
          }}> XYZ ASSETS
          </div></h1>
      <h6 style={{marginTop:30},{color:'rgb(85, 205, 255)'}}>Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </h6>

     
      <Navbar className='color-nav' variant='dark' style={{marginTop:60}}>
        <Container style={{marginLeft:0}}>
        <Navbar.Brand  href='/' >Digital Library</Navbar.Brand>
          <Nav className='me-auto'>
            <Nav.Link href='/'>Home</Nav.Link>
            <Nav.Link href='/about'>About</Nav.Link>
            <Nav.Link href='/assets'>Visit Asset</Nav.Link>
            <Nav.Link href='/addasset'>Add Asset</Nav.Link>
            <Nav.Link href='./register'>Register</Nav.Link>
    y
       </Nav>
       </Container>
      </Navbar>
     
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/about' element={<About />} />
        <Route path='/assets' element={<AssetFetch />} />
        <Route path='/assets/:id' element={<AssetDetails />} />
        <Route path='/addasset' element={<AddAsset />} />
        <Route path='/editassets/:id' element={<AssetEdit />} />
        <Route path='*' element={<NoMatch />} />
        

        <Route path = '/register' element = {<Register/>}/>
      </Routes>
      <br /><br /><br />
      <br /><br /> <br />
      <footer >
        <p style={layLow}>Copyright - All Rights Reserved</p>
      </footer>
    </Router>
</>
  )
}



export default App;
