const express = require('express');
const router = express.Router();
const assetRoutes = require('./assets.route');
const registerRoutes = require('./register.route')

router.use('/assets', assetRoutes);
router.use('/register', registerRoutes);
module.exports = router;