const express = require('express');
const router = express.Router();
const assetController = require('../controller/asset.controller');



router.post('/', assetController.addAsset);
router.get('/', assetController.findAssets);
router.get('/:AssetID', assetController.findAssetById);
router.put('/:AssetID', assetController.updateAsset);
router.delete('/:AssetID', assetController.deleteById);


module.exports = router;
