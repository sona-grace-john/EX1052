const express = require('express');
const router = express.Router();

const registerController = require('../controller/register.controller');

router.post('/',registerController.addRegister);
router.get('/', registerController.findRegisters);
router.get('/:RegisterID', registerController.findRegisterById);
router.put('/:RegisterID', registerController.updateRegister);
router.delete('/:RegisterID', registerController.deleteById);


module.exports = router;