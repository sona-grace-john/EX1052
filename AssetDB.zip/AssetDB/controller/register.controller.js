const registerDao = require('../dao/register.dao');
var registerController = {
    addRegister: addRegister,
    findRegisters: findRegisters,
    findRegisterById: findRegisterById,
    findRegisterByEmail : findRegisterByEmail,
    updateRegister: updateRegister,
    deleteById: deleteById
}

function addRegister(req, res) {
    let register = req.body;
    registerDao.create(register, (err) => {
        if (err) return res.status(500).send("Server error!");
        findRegisterByEmail(email, (err, user) => {
        if (err) return res.status(500).send('Server error!');
        const expiresIn = 24 * 60 * 60;
        const accessToken = jwt.sign({ id: user.id }, SECRET_KEY, {
        expiresIn: expiresIn
        });
        res.status(200).send({
        "user": user, "accessToken": accessToken, "expires_in": expiresIn
        });
        });
        });
}

function findRegisterById(req, res) {
    registerDao.findById(req.params.RegisterID).
        then((data) => {
            res.send(data);
        })
        .catch((error) => {
            console.log(error);
        });
}
function findRegisterByEmail(req, res) {
    registerDao.findById(req.params.Email).
        then((data) => {
            res.send(data);
        })
        .catch((error) => {
            console.log(error);
        });
}

function deleteById(req, res) {
    registerDao.deleteById(req.params.RegisterID).
        then((data) => {
            res.status(200).json({
                message: "Registered User deleted successfully",
                register: data
            })
        })
        .catch((error) => {
            console.log(error);
        });
}

function updateRegister(req, res) {
    registerDao.updateRegister(req.body, req.params.RegisterID).
        then((data) => {
            res.status(200).json({
                message: "User updated successfully",
                register: data
            })
        })
        .catch((error) => {
            console.log(error);
        });
}

function findRegisters(req, res) {
    registerDao.findAll().
        then((data) => {
            res.send(data);
        })
        .catch((error) => {
            console.log(error);
        });
}

module.exports = registerController;