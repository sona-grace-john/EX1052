const Asset = require('../models/asset');
var assetDao = {
    findAll: findAll,
    create: create,
    findById: findById,
    deleteById: deleteById,
    updateAsset: updateAsset
}

function findAll() {
    return Asset.findAll();
}

function findById(AssetID) {
    return Asset.findByPk(AssetID);
}

function deleteById(AssetID) {
    return Asset.destroy({ where: { AssetID: AssetID } });
}

function create(asset) {
    var newAsset = new Asset(asset);
    return newAsset.save();
}

function updateAsset(asset, AssetID) {
    var updateAsset = {
        ModelName: asset.ModelName,
        SerialNumber : asset.SerialNumber,
        My : asset.MyYear,
        PurchaseDate : asset.PurchaseDate,
        Warranty : asset.Warranty,
        From : asset.From,
        To : asset.To
    };
    return Asset.update(updateAsset, { where: { AssetID: AssetID } });
}
module.exports = assetDao;