const Register = require('../models/register');
var registerDao = {
    findAll: findAll,
    create: create,
    findById: findById,
    deleteById: deleteById,
    updateRegister: updateRegister
}

function findAll() {
    return Register.findAll();
}

function findById(RegisterID) {
    return Register.findByPk(RegisterID);
}

function deleteById(RegisterID) {
    return Register.destroy({ where: { RegisterID: RegisterID } });
}

function create(register) {
    var newRegister = new Register(register);
    return newRegister.save();
}

function updateRegister(register, RegisterID) {
    var updateRegister = {
        Name: register.Name,
        Email : register.Email,
        Phone : register.Phone,
        Password : register.Password
    };
    return Register.update(updateRegister, { where: { RegisterID: RegisterID } });
}
module.exports = registerDao;