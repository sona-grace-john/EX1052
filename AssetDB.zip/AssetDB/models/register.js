const Sequelize = require('sequelize');
const db = require('../config/database');

const Register = db.define('register', {
    RegisterID: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },

    //Ignoring Register type id,make id, ad id foreign keys

    Name: {
        type: Sequelize.STRING,
        allowNull: false
    },
    Email: {
        type: Sequelize.STRING,
        allowNull: false
    },
    Phone: {
        type: Sequelize.NUMBER,
        allowNull: false
    },
    Password: {
        type: Sequelize.STRING,
        allowNull: false
    }
})

module.exports = Register;