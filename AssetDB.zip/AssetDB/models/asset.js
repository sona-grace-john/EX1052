const Sequelize = require('sequelize');
const db = require('../config/database');

const Asset = db.define('asset', {
    AssetID: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },

    //Ignoring Asset type id,make id, ad id foreign keys

    ModelName: {
        type: Sequelize.STRING,
        allowNull: false
    },
    SerialNumber: {
        type: Sequelize.STRING,
        allowNull: false
    },
    MyYear: {
        type: Sequelize.STRING,
        allowNull: false
    },
    PurchaseDate: {
        type: Sequelize.DATEONLY,
        allowNull: false
    },
    Warranty: {
        type: Sequelize.STRING,
        allowNull: false
    },
    From: {
        type: Sequelize.DATEONLY,
        allowNull: false
    },
    To: {
        type: Sequelize.DATEONLY,
        allowNull: false
    },
    URL : {
        type: Sequelize.TEXT,
        allowNull: false
    }
})

module.exports = Asset;